#include "memory_manager.hpp"
#include <stdexcept>

namespace ghost::memory {

// Additional implementation details can be added here
// For now, most functionality is implemented in the header
// as it's template-based and needs to be visible at compile time

} // namespace ghost::memory
