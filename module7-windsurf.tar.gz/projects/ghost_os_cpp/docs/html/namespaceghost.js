var namespaceghost =
[
    [ "memory", "namespaceghost_1_1memory.html", "namespaceghost_1_1memory" ],
    [ "os", "namespaceghost_1_1os.html", "namespaceghost_1_1os" ]
];