var classghost_1_1os_1_1_os_toolkit =
[
    [ "Config", "structghost_1_1os_1_1_os_toolkit_1_1_config.html", "structghost_1_1os_1_1_os_toolkit_1_1_config" ],
    [ "Impl", "classghost_1_1os_1_1_os_toolkit_1_1_impl.html", "classghost_1_1os_1_1_os_toolkit_1_1_impl" ],
    [ "OsToolkit", "classghost_1_1os_1_1_os_toolkit.html#a99586e2870f5ea8fc99ca67a1c7ed556", null ],
    [ "~OsToolkit", "classghost_1_1os_1_1_os_toolkit.html#a4750653ba9b7896cbe919ac146c3969b", null ],
    [ "enumerateProcesses", "classghost_1_1os_1_1_os_toolkit.html#a3020178bd07caecace71552ee91d4b20", null ],
    [ "getSystemInfo", "classghost_1_1os_1_1_os_toolkit.html#a06c5c31d00533466360211843175d97c", null ],
    [ "modifyMemoryProtection", "classghost_1_1os_1_1_os_toolkit.html#aec932a2d04b2120dc2be75d4f2845688", null ],
    [ "pimpl", "classghost_1_1os_1_1_os_toolkit.html#a2df913b51cefc298e4f29d982b9c8803", null ]
];