var memory__manager_8hpp =
[
    [ "MemoryManager", "classghost_1_1memory_1_1_memory_manager.html", "classghost_1_1memory_1_1_memory_manager" ],
    [ "MAX_PAGES", "memory__manager_8hpp.html#ac85fd9bafe2da8afa1d9a3f9e29ca50d", null ],
    [ "PAGE_SIZE", "memory__manager_8hpp.html#a8319a4918001e0a7654f35ec2a5ec279", null ]
];