var searchData=
[
  ['max_5fpages_20',['MAX_PAGES',['../namespaceghost_1_1memory.html#ac85fd9bafe2da8afa1d9a3f9e29ca50d',1,'ghost::memory']]],
  ['memory_5fmanager_2ecpp_21',['memory_manager.cpp',['../memory__manager_8cpp.html',1,'']]],
  ['memory_5fmanager_2ehpp_22',['memory_manager.hpp',['../memory__manager_8hpp.html',1,'']]],
  ['memory_5ftotal_23',['memory_total',['../structghost_1_1os_1_1_system_info.html#ad3d636261701b55e3347fb9330621d35',1,'ghost::os::SystemInfo']]],
  ['memory_5fusage_24',['memory_usage',['../structghost_1_1os_1_1_process_info.html#adfa73e66bd06ab560402f641507fac4b',1,'ghost::os::ProcessInfo']]],
  ['memorymanager_25',['MemoryManager',['../classghost_1_1memory_1_1_memory_manager.html',1,'ghost::memory::MemoryManager'],['../classghost_1_1memory_1_1_memory_manager.html#a3dbe2ce59ddfef45eaa18a42fc125cbd',1,'ghost::memory::MemoryManager::MemoryManager()=default'],['../classghost_1_1memory_1_1_memory_manager.html#a17d2f9156de10edbe530d8856c174f9e',1,'ghost::memory::MemoryManager::MemoryManager(const MemoryManager &amp;)=delete']]],
  ['modifymemoryprotection_26',['modifyMemoryProtection',['../classghost_1_1os_1_1_os_toolkit_1_1_impl.html#af74b0907692c603040cd27d47b63099c',1,'ghost::os::OsToolkit::Impl::modifyMemoryProtection()'],['../classghost_1_1os_1_1_platform_ops.html#ad3bc2b7025c831b17538eab2e806dbdb',1,'ghost::os::PlatformOps::modifyMemoryProtection()'],['../classghost_1_1os_1_1_os_toolkit.html#aec932a2d04b2120dc2be75d4f2845688',1,'ghost::os::OsToolkit::modifyMemoryProtection()']]]
];
