var searchData=
[
  ['impl_45',['Impl',['../classghost_1_1os_1_1_os_toolkit_1_1_impl.html',1,'ghost::os::OsToolkit']]]
];
