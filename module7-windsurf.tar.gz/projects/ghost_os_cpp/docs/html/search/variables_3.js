var searchData=
[
  ['max_5fpages_83',['MAX_PAGES',['../namespaceghost_1_1memory.html#ac85fd9bafe2da8afa1d9a3f9e29ca50d',1,'ghost::memory']]],
  ['memory_5ftotal_84',['memory_total',['../structghost_1_1os_1_1_system_info.html#ad3d636261701b55e3347fb9330621d35',1,'ghost::os::SystemInfo']]],
  ['memory_5fusage_85',['memory_usage',['../structghost_1_1os_1_1_process_info.html#adfa73e66bd06ab560402f641507fac4b',1,'ghost::os::ProcessInfo']]]
];
