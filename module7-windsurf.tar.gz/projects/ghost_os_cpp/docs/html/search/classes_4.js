var searchData=
[
  ['platformops_49',['PlatformOps',['../classghost_1_1os_1_1_platform_ops.html',1,'ghost::os']]],
  ['processinfo_50',['ProcessInfo',['../structghost_1_1os_1_1_process_info.html',1,'ghost::os']]]
];
