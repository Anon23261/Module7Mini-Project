var searchData=
[
  ['_7ememorymanager_41',['~MemoryManager',['../classghost_1_1memory_1_1_memory_manager.html#a6e3da8fcec3e06a7a4527b7b605f15be',1,'ghost::memory::MemoryManager']]],
  ['_7eostoolkit_42',['~OsToolkit',['../classghost_1_1os_1_1_os_toolkit.html#a4750653ba9b7896cbe919ac146c3969b',1,'ghost::os::OsToolkit']]],
  ['_7eplatformops_43',['~PlatformOps',['../classghost_1_1os_1_1_platform_ops.html#abe49585428f793f96b895b79b5d42101',1,'ghost::os::PlatformOps']]]
];
