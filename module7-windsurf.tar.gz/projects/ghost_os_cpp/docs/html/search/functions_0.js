var searchData=
[
  ['allocate_5fpage_59',['allocate_page',['../classghost_1_1memory_1_1_memory_manager.html#ad2e8bd56186b8c342d5ddbc9433381d1',1,'ghost::memory::MemoryManager']]]
];
