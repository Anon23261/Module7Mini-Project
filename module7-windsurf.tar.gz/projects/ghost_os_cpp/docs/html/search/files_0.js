var searchData=
[
  ['memory_5fmanager_2ecpp_55',['memory_manager.cpp',['../memory__manager_8cpp.html',1,'']]],
  ['memory_5fmanager_2ehpp_56',['memory_manager.hpp',['../memory__manager_8hpp.html',1,'']]]
];
