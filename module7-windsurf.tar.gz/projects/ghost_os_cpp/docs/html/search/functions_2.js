var searchData=
[
  ['free_5fpage_61',['free_page',['../classghost_1_1memory_1_1_memory_manager.html#a3fdaa4754b23d4c361d58d50feac578b',1,'ghost::memory::MemoryManager']]]
];
