var searchData=
[
  ['memorymanager_67',['MemoryManager',['../classghost_1_1memory_1_1_memory_manager.html#a3dbe2ce59ddfef45eaa18a42fc125cbd',1,'ghost::memory::MemoryManager::MemoryManager()=default'],['../classghost_1_1memory_1_1_memory_manager.html#a17d2f9156de10edbe530d8856c174f9e',1,'ghost::memory::MemoryManager::MemoryManager(const MemoryManager &amp;)=delete']]],
  ['modifymemoryprotection_68',['modifyMemoryProtection',['../classghost_1_1os_1_1_os_toolkit_1_1_impl.html#af74b0907692c603040cd27d47b63099c',1,'ghost::os::OsToolkit::Impl::modifyMemoryProtection()'],['../classghost_1_1os_1_1_platform_ops.html#ad3bc2b7025c831b17538eab2e806dbdb',1,'ghost::os::PlatformOps::modifyMemoryProtection()'],['../classghost_1_1os_1_1_os_toolkit.html#aec932a2d04b2120dc2be75d4f2845688',1,'ghost::os::OsToolkit::modifyMemoryProtection()']]]
];
