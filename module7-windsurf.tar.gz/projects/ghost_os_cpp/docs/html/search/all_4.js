var searchData=
[
  ['get_5ffree_5fpages_12',['get_free_pages',['../classghost_1_1memory_1_1_memory_manager.html#a74f35cb4244465479767f7cd58b025cf',1,'ghost::memory::MemoryManager']]],
  ['get_5fused_5fpages_13',['get_used_pages',['../classghost_1_1memory_1_1_memory_manager.html#a2bc996ab37ef22563d63517663547cdd',1,'ghost::memory::MemoryManager']]],
  ['getsysteminfo_14',['getSystemInfo',['../classghost_1_1os_1_1_os_toolkit_1_1_impl.html#ae5dc89bcea90e097102a799c6309b137',1,'ghost::os::OsToolkit::Impl::getSystemInfo()'],['../classghost_1_1os_1_1_platform_ops.html#ae8d0d5a1a30fd2abc8553e9eba89f326',1,'ghost::os::PlatformOps::getSystemInfo()'],['../classghost_1_1os_1_1_os_toolkit.html#a06c5c31d00533466360211843175d97c',1,'ghost::os::OsToolkit::getSystemInfo()']]],
  ['ghost_15',['ghost',['../namespaceghost.html',1,'']]],
  ['memory_16',['memory',['../namespaceghost_1_1memory.html',1,'ghost']]],
  ['os_17',['os',['../namespaceghost_1_1os.html',1,'ghost']]]
];
