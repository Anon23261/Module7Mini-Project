var indexSectionsWithContent =
{
  0: "acefgimnops~",
  1: "cimops",
  2: "g",
  3: "mo",
  4: "aefgimo~",
  5: "acemnop"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables"
};

