var searchData=
[
  ['architecture_75',['architecture',['../structghost_1_1os_1_1_system_info.html#a56e154d8c2d53c27431de8dbc9dc3766',1,'ghost::os::SystemInfo']]]
];
