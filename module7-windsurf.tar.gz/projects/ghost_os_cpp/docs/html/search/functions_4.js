var searchData=
[
  ['impl_65',['Impl',['../classghost_1_1os_1_1_os_toolkit_1_1_impl.html#adaaff7f1608f8db28a1594e1cf3849d6',1,'ghost::os::OsToolkit::Impl']]],
  ['instance_66',['instance',['../classghost_1_1memory_1_1_memory_manager.html#a82fcf2e0645465c8e01c7337cb7a15ad',1,'ghost::memory::MemoryManager']]]
];
