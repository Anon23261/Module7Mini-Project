var searchData=
[
  ['name_86',['name',['../structghost_1_1os_1_1_process_info.html#a4b4891eeaf7e331913efa55149dc1725',1,'ghost::os::ProcessInfo']]]
];
