var searchData=
[
  ['os_5ftype_87',['os_type',['../structghost_1_1os_1_1_system_info.html#adbe3ef8387f28082b75901d454c28e78',1,'ghost::os::SystemInfo']]]
];
