var searchData=
[
  ['systeminfo_51',['SystemInfo',['../structghost_1_1os_1_1_system_info.html',1,'ghost::os']]]
];
