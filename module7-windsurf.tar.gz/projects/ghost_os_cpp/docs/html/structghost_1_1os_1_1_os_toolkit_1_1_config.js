var structghost_1_1os_1_1_os_toolkit_1_1_config =
[
    [ "enable_hardware_access", "structghost_1_1os_1_1_os_toolkit_1_1_config.html#a59f52754b6e1592292502809931f11e1", null ],
    [ "enable_memory_manipulation", "structghost_1_1os_1_1_os_toolkit_1_1_config.html#afc3a3608c686b0fdc7cdca0982ee3b17", null ],
    [ "enable_process_manipulation", "structghost_1_1os_1_1_os_toolkit_1_1_config.html#aaaf53e6afe7e5225ad955b293f4e81a1", null ]
];