var structghost_1_1os_1_1_process_info =
[
    [ "cpu_usage", "structghost_1_1os_1_1_process_info.html#aee11470c0a9a97b5dd3d3f308b5ad9a0", null ],
    [ "memory_usage", "structghost_1_1os_1_1_process_info.html#adfa73e66bd06ab560402f641507fac4b", null ],
    [ "name", "structghost_1_1os_1_1_process_info.html#a4b4891eeaf7e331913efa55149dc1725", null ],
    [ "pid", "structghost_1_1os_1_1_process_info.html#a0c1e5150b9af8f989e754376ccf351b4", null ]
];