var namespaces_dup =
[
    [ "ghost", "namespaceghost.html", "namespaceghost" ]
];