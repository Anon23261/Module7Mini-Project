var classghost_1_1os_1_1_os_toolkit_error =
[
    [ "OsToolkitError", "classghost_1_1os_1_1_os_toolkit_error.html#a58cdeebb7c5b3a629ee174ea59fa74a1", null ]
];