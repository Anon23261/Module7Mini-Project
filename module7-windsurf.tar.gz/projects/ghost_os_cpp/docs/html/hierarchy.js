var hierarchy =
[
    [ "ghost::os::OsToolkit::Config", "structghost_1_1os_1_1_os_toolkit_1_1_config.html", null ],
    [ "std::exception", null, [
      [ "std::runtime_error", null, [
        [ "ghost::os::OsToolkitError", "classghost_1_1os_1_1_os_toolkit_error.html", null ]
      ] ]
    ] ],
    [ "ghost::os::OsToolkit::Impl", "classghost_1_1os_1_1_os_toolkit_1_1_impl.html", null ],
    [ "ghost::memory::MemoryManager", "classghost_1_1memory_1_1_memory_manager.html", null ],
    [ "ghost::os::OsToolkit", "classghost_1_1os_1_1_os_toolkit.html", null ],
    [ "ghost::os::PlatformOps", "classghost_1_1os_1_1_platform_ops.html", null ],
    [ "ghost::os::ProcessInfo", "structghost_1_1os_1_1_process_info.html", null ],
    [ "ghost::os::SystemInfo", "structghost_1_1os_1_1_system_info.html", null ]
];