var classghost_1_1memory_1_1_memory_manager =
[
    [ "MemoryManager", "classghost_1_1memory_1_1_memory_manager.html#a3dbe2ce59ddfef45eaa18a42fc125cbd", null ],
    [ "~MemoryManager", "classghost_1_1memory_1_1_memory_manager.html#a6e3da8fcec3e06a7a4527b7b605f15be", null ],
    [ "MemoryManager", "classghost_1_1memory_1_1_memory_manager.html#a17d2f9156de10edbe530d8856c174f9e", null ],
    [ "allocate_page", "classghost_1_1memory_1_1_memory_manager.html#ad2e8bd56186b8c342d5ddbc9433381d1", null ],
    [ "free_page", "classghost_1_1memory_1_1_memory_manager.html#a3fdaa4754b23d4c361d58d50feac578b", null ],
    [ "get_free_pages", "classghost_1_1memory_1_1_memory_manager.html#a74f35cb4244465479767f7cd58b025cf", null ],
    [ "get_used_pages", "classghost_1_1memory_1_1_memory_manager.html#a2bc996ab37ef22563d63517663547cdd", null ],
    [ "instance", "classghost_1_1memory_1_1_memory_manager.html#a82fcf2e0645465c8e01c7337cb7a15ad", null ],
    [ "operator=", "classghost_1_1memory_1_1_memory_manager.html#a3f1fd2a5874b5430fce69dfc69de57fb", null ],
    [ "page_bitmap", "classghost_1_1memory_1_1_memory_manager.html#ae6d9d872f7d4640b366709d4cb7a835b", null ]
];