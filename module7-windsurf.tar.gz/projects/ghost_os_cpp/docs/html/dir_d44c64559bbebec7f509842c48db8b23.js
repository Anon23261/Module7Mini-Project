var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "os_toolkit.hpp", "os__toolkit_8hpp.html", [
      [ "SystemInfo", "structghost_1_1os_1_1_system_info.html", "structghost_1_1os_1_1_system_info" ],
      [ "ProcessInfo", "structghost_1_1os_1_1_process_info.html", "structghost_1_1os_1_1_process_info" ],
      [ "OsToolkitError", "classghost_1_1os_1_1_os_toolkit_error.html", "classghost_1_1os_1_1_os_toolkit_error" ],
      [ "PlatformOps", "classghost_1_1os_1_1_platform_ops.html", "classghost_1_1os_1_1_platform_ops" ],
      [ "OsToolkit", "classghost_1_1os_1_1_os_toolkit.html", "classghost_1_1os_1_1_os_toolkit" ],
      [ "Config", "structghost_1_1os_1_1_os_toolkit_1_1_config.html", "structghost_1_1os_1_1_os_toolkit_1_1_config" ]
    ] ]
];