var annotated_dup =
[
    [ "ghost", "namespaceghost.html", [
      [ "memory", "namespaceghost_1_1memory.html", [
        [ "MemoryManager", "classghost_1_1memory_1_1_memory_manager.html", "classghost_1_1memory_1_1_memory_manager" ]
      ] ],
      [ "os", "namespaceghost_1_1os.html", [
        [ "SystemInfo", "structghost_1_1os_1_1_system_info.html", "structghost_1_1os_1_1_system_info" ],
        [ "ProcessInfo", "structghost_1_1os_1_1_process_info.html", "structghost_1_1os_1_1_process_info" ],
        [ "OsToolkitError", "classghost_1_1os_1_1_os_toolkit_error.html", "classghost_1_1os_1_1_os_toolkit_error" ],
        [ "PlatformOps", "classghost_1_1os_1_1_platform_ops.html", "classghost_1_1os_1_1_platform_ops" ],
        [ "OsToolkit", "classghost_1_1os_1_1_os_toolkit.html", "classghost_1_1os_1_1_os_toolkit" ]
      ] ]
    ] ]
];