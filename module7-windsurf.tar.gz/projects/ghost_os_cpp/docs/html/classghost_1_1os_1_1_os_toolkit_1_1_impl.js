var classghost_1_1os_1_1_os_toolkit_1_1_impl =
[
    [ "Impl", "classghost_1_1os_1_1_os_toolkit_1_1_impl.html#adaaff7f1608f8db28a1594e1cf3849d6", null ],
    [ "enumerateProcesses", "classghost_1_1os_1_1_os_toolkit_1_1_impl.html#ae3bbe9ac9086761f9d43a83898fccc7a", null ],
    [ "getSystemInfo", "classghost_1_1os_1_1_os_toolkit_1_1_impl.html#ae5dc89bcea90e097102a799c6309b137", null ],
    [ "modifyMemoryProtection", "classghost_1_1os_1_1_os_toolkit_1_1_impl.html#af74b0907692c603040cd27d47b63099c", null ],
    [ "config_", "classghost_1_1os_1_1_os_toolkit_1_1_impl.html#ac1237c2f7be907783ab2247253e1adb3", null ]
];