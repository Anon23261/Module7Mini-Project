var classghost_1_1os_1_1_platform_ops =
[
    [ "~PlatformOps", "classghost_1_1os_1_1_platform_ops.html#abe49585428f793f96b895b79b5d42101", null ],
    [ "enumerateProcesses", "classghost_1_1os_1_1_platform_ops.html#a6961231f32d1d0110bec206d2a7407d4", null ],
    [ "getSystemInfo", "classghost_1_1os_1_1_platform_ops.html#ae8d0d5a1a30fd2abc8553e9eba89f326", null ],
    [ "modifyMemoryProtection", "classghost_1_1os_1_1_platform_ops.html#ad3bc2b7025c831b17538eab2e806dbdb", null ]
];