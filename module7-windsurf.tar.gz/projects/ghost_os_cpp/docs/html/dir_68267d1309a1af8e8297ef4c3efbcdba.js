var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "memory", "dir_94d7edf6f8f3d9af5fd63c44172da41c.html", "dir_94d7edf6f8f3d9af5fd63c44172da41c" ],
    [ "os_toolkit.cpp", "os__toolkit_8cpp.html", [
      [ "Impl", "classghost_1_1os_1_1_os_toolkit_1_1_impl.html", "classghost_1_1os_1_1_os_toolkit_1_1_impl" ]
    ] ]
];