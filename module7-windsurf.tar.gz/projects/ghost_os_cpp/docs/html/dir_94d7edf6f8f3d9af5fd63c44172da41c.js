var dir_94d7edf6f8f3d9af5fd63c44172da41c =
[
    [ "memory_manager.cpp", "memory__manager_8cpp.html", null ],
    [ "memory_manager.hpp", "memory__manager_8hpp.html", "memory__manager_8hpp" ]
];