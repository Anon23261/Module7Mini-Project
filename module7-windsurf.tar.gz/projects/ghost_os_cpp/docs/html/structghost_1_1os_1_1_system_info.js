var structghost_1_1os_1_1_system_info =
[
    [ "architecture", "structghost_1_1os_1_1_system_info.html#a56e154d8c2d53c27431de8dbc9dc3766", null ],
    [ "cpu_cores", "structghost_1_1os_1_1_system_info.html#a5df0899ebf8754ce9aa4094e5269a853", null ],
    [ "cpu_features", "structghost_1_1os_1_1_system_info.html#a39537543878e350bc1eeef43c1ab9c10", null ],
    [ "memory_total", "structghost_1_1os_1_1_system_info.html#ad3d636261701b55e3347fb9330621d35", null ],
    [ "os_type", "structghost_1_1os_1_1_system_info.html#adbe3ef8387f28082b75901d454c28e78", null ]
];