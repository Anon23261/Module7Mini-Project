var namespaceghost_1_1memory =
[
    [ "MemoryManager", "classghost_1_1memory_1_1_memory_manager.html", "classghost_1_1memory_1_1_memory_manager" ],
    [ "MAX_PAGES", "namespaceghost_1_1memory.html#ac85fd9bafe2da8afa1d9a3f9e29ca50d", null ],
    [ "PAGE_SIZE", "namespaceghost_1_1memory.html#a8319a4918001e0a7654f35ec2a5ec279", null ]
];